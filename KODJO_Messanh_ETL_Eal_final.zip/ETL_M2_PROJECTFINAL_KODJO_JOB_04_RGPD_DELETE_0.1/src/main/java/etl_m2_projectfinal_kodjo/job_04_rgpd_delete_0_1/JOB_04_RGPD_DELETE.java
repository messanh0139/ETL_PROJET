// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package etl_m2_projectfinal_kodjo.job_04_rgpd_delete_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.MDM;
import routines.StringHandling;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: JOB_04_RGPD_DELETE Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class JOB_04_RGPD_DELETE implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "JOB_04_RGPD_DELETE.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(JOB_04_RGPD_DELETE.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "JOB_04_RGPD_DELETE";
	private final String projectName = "ETL_M2_PROJECTFINAL_KODJO";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					JOB_04_RGPD_DELETE.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(JOB_04_RGPD_DELETE.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];
		static byte[] commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];

		public String errorCode;

		public String getErrorCode() {
			return this.errorCode;
		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.errorCode = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.errorCode = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.errorCode, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.errorCode, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("errorCode=" + errorCode);
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (errorCode == null) {
				sb.append("<null>");
			} else {
				sb.append(errorCode);
			}

			sb.append("|");

			if (errorMessage == null) {
				sb.append("<null>");
			} else {
				sb.append(errorMessage);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];
		static byte[] commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];

		public String customer_id;

		public String getCustomer_id() {
			return this.customer_id;
		}

		public String email;

		public String getEmail() {
			return this.email;
		}

		public String errorCode;

		public String getErrorCode() {
			return this.errorCode;
		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.customer_id = readString(dis);

					this.email = readString(dis);

					this.errorCode = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.customer_id = readString(dis);

					this.email = readString(dis);

					this.errorCode = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.customer_id, dos);

				// String

				writeString(this.email, dos);

				// String

				writeString(this.errorCode, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.customer_id, dos);

				// String

				writeString(this.email, dos);

				// String

				writeString(this.errorCode, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("customer_id=" + customer_id);
			sb.append(",email=" + email);
			sb.append(",errorCode=" + errorCode);
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (customer_id == null) {
				sb.append("<null>");
			} else {
				sb.append(customer_id);
			}

			sb.append("|");

			if (email == null) {
				sb.append("<null>");
			} else {
				sb.append(email);
			}

			sb.append("|");

			if (errorCode == null) {
				sb.append("<null>");
			} else {
				sb.append(errorCode);
			}

			sb.append("|");

			if (errorMessage == null) {
				sb.append("<null>");
			} else {
				sb.append(errorMessage);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];
		static byte[] commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[0];

		public String customer_id;

		public String getCustomer_id() {
			return this.customer_id;
		}

		public String email;

		public String getEmail() {
			return this.email;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length) {
					if (length < 1024 && commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE.length == 0) {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[1024];
					} else {
						commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length);
				strReturn = new String(commonByteArray_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.customer_id = readString(dis);

					this.email = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_ETL_M2_PROJECTFINAL_KODJO_JOB_04_RGPD_DELETE) {

				try {

					int length = 0;

					this.customer_id = readString(dis);

					this.email = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.customer_id, dos);

				// String

				writeString(this.email, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.customer_id, dos);

				// String

				writeString(this.email, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("customer_id=" + customer_id);
			sb.append(",email=" + email);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (customer_id == null) {
				sb.append("<null>");
			} else {
				sb.append(customer_id);
			}

			sb.append("|");

			if (email == null) {
				sb.append("<null>");
			} else {
				sb.append(email);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();
				row3Struct row3 = new row3Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_VERSION" + " = " + "V9_X");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"5432\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"etl_m2_target\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SCHEMA_DB" + " = " + "\"public\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"postgres\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:Ls+TxGUFuR9F/3lVnyMO4uHnHM5VJzRptLdKgl0xtlWZP4jPn4CAsDVNCmg=")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"RGPD_LOG\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}

				String dbschema_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "public";

				String tableName_tDBOutput_1 = null;
				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = ("RGPD_LOG");
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("RGPD_LOG");
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				boolean whetherReject_tDBOutput_1 = false;

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + ("org.postgresql.Driver") + ("."));
				java.lang.Class.forName("org.postgresql.Driver");

				String url_tDBOutput_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "etl_m2_target";
				dbUser_tDBOutput_1 = "postgres";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:GpODZ4J4GGJoppFAM83SkSQPkvjk6uMhF3pGhmeJElMb8FwBXuOW42iisBk=");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));

				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				int count_tDBOutput_1 = 0;
				String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1
						+ "\" (\"errorCode\",\"errorMessage\") VALUES (?,?)";

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tDBRow_2 begin ] start
				 */

				ok_Hash.put("tDBRow_2", false);
				start_Hash.put("tDBRow_2", System.currentTimeMillis());

				currentComponent = "tDBRow_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tDBRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBRow_2 = new StringBuilder();
							log4jParamters_tDBRow_2.append("Parameters:");
							log4jParamters_tDBRow_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("DB_VERSION" + " = " + "V9_X");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("PORT" + " = " + "\"5432\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("DBNAME" + " = " + "\"etl_m2_target\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("SCHEMA_DB" + " = " + "\"public\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("USER" + " = " + "\"postgres\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:sXEJcmJP7qDxUi3Psif9qrfW2hqRLVZMDKOIxAR25BcZdQgADZXUwd8ym2c=")
									.substring(0, 4) + "...");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2
									.append("QUERY" + " = " + "\"DELETE FROM CLIENTS WHERE customer_id = ?\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBRow_2.append(" | ");
							log4jParamters_tDBRow_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlRow");
							log4jParamters_tDBRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBRow_2 - " + (log4jParamters_tDBRow_2));
						}
					}
					new BytesLimit65535_tDBRow_2().limitLog4jByte();
				}

				java.sql.Connection conn_tDBRow_2 = null;
				String query_tDBRow_2 = "";
				boolean whetherReject_tDBRow_2 = false;
				String driverClass_tDBRow_2 = "org.postgresql.Driver";
				java.lang.Class jdbcclazz_tDBRow_2 = java.lang.Class.forName(driverClass_tDBRow_2);

				String url_tDBRow_2 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "etl_m2_target";

				log.debug("tDBRow_2 - Driver ClassName: " + driverClass_tDBRow_2 + ".");

				String dbUser_tDBRow_2 = "postgres";

				final String decryptedPassword_tDBRow_2 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:hyliAJxjAXC6NqoTjZCkM85nvk2zouFg0n4a9UPqpfv6wFjdv5CizwrjUj4=");

				String dbPwd_tDBRow_2 = decryptedPassword_tDBRow_2;

				log.debug("tDBRow_2 - Connection attempt to '" + url_tDBRow_2 + "' with the username '"
						+ dbUser_tDBRow_2 + "'.");

				conn_tDBRow_2 = java.sql.DriverManager.getConnection(url_tDBRow_2, dbUser_tDBRow_2, dbPwd_tDBRow_2);

				log.debug("tDBRow_2 - Connection to '" + url_tDBRow_2 + "' has succeeded.");

				resourceMap.put("conn_tDBRow_2", conn_tDBRow_2);
				if (conn_tDBRow_2.getAutoCommit()) {

					log.debug("tDBRow_2 - Connection is set auto commit to 'false'.");

					conn_tDBRow_2.setAutoCommit(false);

				}
				int commitEvery_tDBRow_2 = 10000;
				int commitCounter_tDBRow_2 = 0;

				java.sql.Statement stmt_tDBRow_2 = conn_tDBRow_2.createStatement();
				resourceMap.put("stmt_tDBRow_2", stmt_tDBRow_2);

				/**
				 * [tDBRow_2 begin ] stop
				 */

				/**
				 * [tDBRow_1 begin ] start
				 */

				ok_Hash.put("tDBRow_1", false);
				start_Hash.put("tDBRow_1", System.currentTimeMillis());

				currentComponent = "tDBRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tDBRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBRow_1 = new StringBuilder();
							log4jParamters_tDBRow_1.append("Parameters:");
							log4jParamters_tDBRow_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("DB_VERSION" + " = " + "V9_X");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("PORT" + " = " + "\"5432\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("DBNAME" + " = " + "\"etl_m2_target\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("SCHEMA_DB" + " = " + "\"public\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("USER" + " = " + "\"postgres\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:SiY3ceoyERjIv+hMBTBIeRky69Xos0H5RBimwzKukbDLLQ2TfOBVioKRCQw=")
									.substring(0, 4) + "...");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("QUERY" + " = "
									+ "\"UPDATE TRANSACTIONS SET customer_id = 'ANONYMIZED' WHERE customer_id = ?\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBRow_1.append(" | ");
							log4jParamters_tDBRow_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlRow");
							log4jParamters_tDBRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBRow_1 - " + (log4jParamters_tDBRow_1));
						}
					}
					new BytesLimit65535_tDBRow_1().limitLog4jByte();
				}

				java.sql.Connection conn_tDBRow_1 = null;
				String query_tDBRow_1 = "";
				boolean whetherReject_tDBRow_1 = false;
				String driverClass_tDBRow_1 = "org.postgresql.Driver";
				java.lang.Class jdbcclazz_tDBRow_1 = java.lang.Class.forName(driverClass_tDBRow_1);

				String url_tDBRow_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "etl_m2_target";

				log.debug("tDBRow_1 - Driver ClassName: " + driverClass_tDBRow_1 + ".");

				String dbUser_tDBRow_1 = "postgres";

				final String decryptedPassword_tDBRow_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:KVSwn3ixiMWNCGyoC+e/R8Y+fKMP8DIwfsJCF+MI67VCZrH/L/tCvU2Qkmg=");

				String dbPwd_tDBRow_1 = decryptedPassword_tDBRow_1;

				log.debug("tDBRow_1 - Connection attempt to '" + url_tDBRow_1 + "' with the username '"
						+ dbUser_tDBRow_1 + "'.");

				conn_tDBRow_1 = java.sql.DriverManager.getConnection(url_tDBRow_1, dbUser_tDBRow_1, dbPwd_tDBRow_1);

				log.debug("tDBRow_1 - Connection to '" + url_tDBRow_1 + "' has succeeded.");

				resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
				if (conn_tDBRow_1.getAutoCommit()) {

					log.debug("tDBRow_1 - Connection is set auto commit to 'false'.");

					conn_tDBRow_1.setAutoCommit(false);

				}
				int commitEvery_tDBRow_1 = 10000;
				int commitCounter_tDBRow_1 = 0;

				java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
				resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);

				/**
				 * [tDBRow_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				int NB_ITERATE_tDBInput_2 = 0; // for statistics

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DB_VERSION" + " = " + "V9_X");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"5432\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"etl_m2_target\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SCHEMA_DB" + " = " + "\"public\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"postgres\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:zwdhso5+cJo1G56UzrMy2tQQ6nJKiqvOFRANlQ4qkgyKpjP2dfNTL+Po7ow=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT customer_id, email FROM CLIENTS WHERE customer_id = \" + row2.customer_id + \" OR email = '\" + row2.email + \"'\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USE_CURSOR" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append(
									"TRIM_COLUMN" + " = " + "[{TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("customer_id")
											+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("email") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}

				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "postgres";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:nGGTHVczGnXX5xVgVOU1L89z/J+15lzKy1zeTEL2hrVRRLqGP5+iEnTNpwk=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String url_tDBInput_1 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "etl_m2_target";

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				log.debug("tDBInput_1 - Connection is set auto commit to 'false'.");

				conn_tDBInput_1.setAutoCommit(false);

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT customer_id, email FROM CLIENTS WHERE customer_id = "
						+ row2.customer_id + " OR email = '" + row2.email + "'";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.customer_id = null;
						} else {

							row1.customer_id = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.email = null;
						} else {

							row1.email = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tDBRow_1 main ] start
						 */

						currentComponent = "tDBRow_1";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row1"

							);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						row2 = null;

						query_tDBRow_1 = "UPDATE TRANSACTIONS SET customer_id = 'ANONYMIZED' WHERE customer_id = ?";
						whetherReject_tDBRow_1 = false;
						log.debug("tDBRow_1 - Executing the query: '" + query_tDBRow_1 + "'.");

						globalMap.put("tDBRow_1_QUERY", query_tDBRow_1);
						try {
							stmt_tDBRow_1.execute(query_tDBRow_1);

							log.debug("tDBRow_1 - Execute the query: '" + query_tDBRow_1 + "' has finished.");

						} catch (java.lang.Exception e) {
							whetherReject_tDBRow_1 = true;

							row2 = new row2Struct();

							row2.customer_id = row1.customer_id;

							row2.email = row1.email;

							row2.errorCode = ((java.sql.SQLException) e).getSQLState();
							row2.errorMessage = e.getMessage() + " - Line: " + tos_count_tDBRow_1;

						}

						if (!whetherReject_tDBRow_1) {

						}

						commitCounter_tDBRow_1++;
						if (commitEvery_tDBRow_1 <= commitCounter_tDBRow_1) {

							log.debug("tDBRow_1 - Connection starting to commit.");

							conn_tDBRow_1.commit();

							log.debug("tDBRow_1 - Connection commit has succeeded.");

							commitCounter_tDBRow_1 = 0;
						}

						tos_count_tDBRow_1++;

						/**
						 * [tDBRow_1 main ] stop
						 */

						/**
						 * [tDBRow_1 process_data_begin ] start
						 */

						currentComponent = "tDBRow_1";

						/**
						 * [tDBRow_1 process_data_begin ] stop
						 */
// Start of branch "row2"
						if (row2 != null) {
							row3 = null;

							/**
							 * [tDBRow_2 main ] start
							 */

							currentComponent = "tDBRow_2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row2"

								);
							}

							if (log.isTraceEnabled()) {
								log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
							}

							row3 = null;

							query_tDBRow_2 = "DELETE FROM CLIENTS WHERE customer_id = ?";
							whetherReject_tDBRow_2 = false;
							log.debug("tDBRow_2 - Executing the query: '" + query_tDBRow_2 + "'.");

							globalMap.put("tDBRow_2_QUERY", query_tDBRow_2);
							try {
								stmt_tDBRow_2.execute(query_tDBRow_2);

								log.debug("tDBRow_2 - Execute the query: '" + query_tDBRow_2 + "' has finished.");

							} catch (java.lang.Exception e) {
								whetherReject_tDBRow_2 = true;

								row3 = new row3Struct();

								row3.errorCode = ((java.sql.SQLException) e).getSQLState();
								row3.errorMessage = e.getMessage() + " - Line: " + tos_count_tDBRow_2;

							}

							if (!whetherReject_tDBRow_2) {

							}

							commitCounter_tDBRow_2++;
							if (commitEvery_tDBRow_2 <= commitCounter_tDBRow_2) {

								log.debug("tDBRow_2 - Connection starting to commit.");

								conn_tDBRow_2.commit();

								log.debug("tDBRow_2 - Connection commit has succeeded.");

								commitCounter_tDBRow_2 = 0;
							}

							tos_count_tDBRow_2++;

							/**
							 * [tDBRow_2 main ] stop
							 */

							/**
							 * [tDBRow_2 process_data_begin ] start
							 */

							currentComponent = "tDBRow_2";

							/**
							 * [tDBRow_2 process_data_begin ] stop
							 */
// Start of branch "row3"
							if (row3 != null) {

								/**
								 * [tDBOutput_1 main ] start
								 */

								currentComponent = "tDBOutput_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row3"

									);
								}

								if (log.isTraceEnabled()) {
									log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
								}

								whetherReject_tDBOutput_1 = false;
								if (row3.errorCode == null) {
									pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(1, row3.errorCode);
								}

								if (row3.errorMessage == null) {
									pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(2, row3.errorMessage);
								}

								pstmt_tDBOutput_1.addBatch();
								nb_line_tDBOutput_1++;

								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
											+ (" to the ") + ("INSERT") + (" batch."));
								batchSizeCounter_tDBOutput_1++;

								if ((batchSize_tDBOutput_1 > 0)
										&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
									try {
										int countSum_tDBOutput_1 = 0;

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
													: countEach_tDBOutput_1);
										}
										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
													+ (" batch execution has succeeded."));
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

										batchSizeCounter_tDBOutput_1 = 0;
									} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
										java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
												sqle_tDBOutput_1 = null;
										String errormessage_tDBOutput_1;
										if (ne_tDBOutput_1 != null) {
											// build new exception to provide the original cause
											sqle_tDBOutput_1 = new java.sql.SQLException(
													e_tDBOutput_1.getMessage() + "\ncaused by: "
															+ ne_tDBOutput_1.getMessage(),
													ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(),
													ne_tDBOutput_1);
											errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
										} else {
											errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
										}

										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
											countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
													: countEach_tDBOutput_1);
										}
										rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

										insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

										log.error("tDBOutput_1 - " + (errormessage_tDBOutput_1));
										System.err.println(errormessage_tDBOutput_1);

									}
								}

								commitCounter_tDBOutput_1++;
								if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
									if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
										try {
											int countSum_tDBOutput_1 = 0;

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
														: countEach_tDBOutput_1);
											}
											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
											rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

											batchSizeCounter_tDBOutput_1 = 0;
										} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
											java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
													sqle_tDBOutput_1 = null;
											String errormessage_tDBOutput_1;
											if (ne_tDBOutput_1 != null) {
												// build new exception to provide the original cause
												sqle_tDBOutput_1 = new java.sql.SQLException(
														e_tDBOutput_1.getMessage() + "\ncaused by: "
																+ ne_tDBOutput_1.getMessage(),
														ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(),
														ne_tDBOutput_1);
												errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
											} else {
												errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
											}

											int countSum_tDBOutput_1 = 0;
											for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
														: countEach_tDBOutput_1);
											}
											rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

											log.error("tDBOutput_1 - " + (errormessage_tDBOutput_1));
											System.err.println(errormessage_tDBOutput_1);

										}
									}
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
													+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
									}
									conn_tDBOutput_1.commit();
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
										rowsToCommitCount_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1 = 0;
								}

								tos_count_tDBOutput_1++;

								/**
								 * [tDBOutput_1 main ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_end ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_end ] stop
								 */

							} // End of branch "row3"

							/**
							 * [tDBRow_2 process_data_end ] start
							 */

							currentComponent = "tDBRow_2";

							/**
							 * [tDBRow_2 process_data_end ] stop
							 */

						} // End of branch "row2"

						/**
						 * [tDBRow_1 process_data_end ] start
						 */

						currentComponent = "tDBRow_1";

						/**
						 * [tDBRow_1 process_data_end ] stop
						 */

						NB_ITERATE_tDBInput_2++;

						if (execStat) {
							runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tDBInput_2);
							// Thread.sleep(1000);
						}

						/**
						 * [tDBInput_2 begin ] start
						 */

						ok_Hash.put("tDBInput_2", false);
						start_Hash.put("tDBInput_2", System.currentTimeMillis());

						currentComponent = "tDBInput_2";

						int tos_count_tDBInput_2 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBInput_2 - " + ("Start to work."));
						if (log.isDebugEnabled()) {
							class BytesLimit65535_tDBInput_2 {
								public void limitLog4jByte() throws Exception {
									StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
									log4jParamters_tDBInput_2.append("Parameters:");
									log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("DB_VERSION" + " = " + "V9_X");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("HOST" + " = " + "\"localhost\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("PORT" + " = " + "\"5432\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("DBNAME" + " = " + "\"etl_m2_target\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("SCHEMA_DB" + " = " + "\"public\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("USER" + " = " + "\"postgres\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("PASS" + " = " + String.valueOf(
											"enc:routine.encryption.key.v1:AUnDqVfAlu0VswwaBI2+qvLCFIUZiRJO/x4frwOcISxPmUYJrFGkNB8wJzI=")
											.substring(0, 4) + "...");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("QUERY" + " = "
											+ "\"SELECT COUNT(*) AS nb FROM TRANSACTIONS WHERE customer_id = ?\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("PROPERTIES" + " = " + "\"\"");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("USE_CURSOR" + " = " + "false");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
											+ ", SCHEMA_COLUMN=" + ("customer_id") + "}, {TRIM=" + ("false")
											+ ", SCHEMA_COLUMN=" + ("email") + "}]");
									log4jParamters_tDBInput_2.append(" | ");
									log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlInput");
									log4jParamters_tDBInput_2.append(" | ");
									if (log.isDebugEnabled())
										log.debug("tDBInput_2 - " + (log4jParamters_tDBInput_2));
								}
							}
							new BytesLimit65535_tDBInput_2().limitLog4jByte();
						}

						int nb_line_tDBInput_2 = 0;
						java.sql.Connection conn_tDBInput_2 = null;
						String driverClass_tDBInput_2 = "org.postgresql.Driver";
						java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
						String dbUser_tDBInput_2 = "postgres";

						final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword(
								"enc:routine.encryption.key.v1:geWOzhPp/JXletTDazQnW1166CH9AgvobhbCW7KUsKkWtnDjZbJw2NNX9OU=");

						String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

						String url_tDBInput_2 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/"
								+ "etl_m2_target";

						log.debug("tDBInput_2 - Driver ClassName: " + driverClass_tDBInput_2 + ".");

						log.debug("tDBInput_2 - Connection attempt to '" + url_tDBInput_2 + "' with the username '"
								+ dbUser_tDBInput_2 + "'.");

						conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2, dbUser_tDBInput_2,
								dbPwd_tDBInput_2);
						log.debug("tDBInput_2 - Connection to '" + url_tDBInput_2 + "' has succeeded.");

						log.debug("tDBInput_2 - Connection is set auto commit to 'false'.");

						conn_tDBInput_2.setAutoCommit(false);

						java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

						String dbquery_tDBInput_2 = "SELECT COUNT(*) AS nb FROM TRANSACTIONS WHERE customer_id = ?";

						log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");

						globalMap.put("tDBInput_2_QUERY", dbquery_tDBInput_2);
						java.sql.ResultSet rs_tDBInput_2 = null;

						try {
							rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
							java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
							int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

							String tmpContent_tDBInput_2 = null;

							log.debug("tDBInput_2 - Retrieving records from the database.");

							while (rs_tDBInput_2.next()) {
								nb_line_tDBInput_2++;

								/**
								 * [tDBInput_2 begin ] stop
								 */

								/**
								 * [tDBInput_2 main ] start
								 */

								currentComponent = "tDBInput_2";

								tos_count_tDBInput_2++;

								/**
								 * [tDBInput_2 main ] stop
								 */

								/**
								 * [tDBInput_2 process_data_begin ] start
								 */

								currentComponent = "tDBInput_2";

								/**
								 * [tDBInput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBInput_2 process_data_end ] start
								 */

								currentComponent = "tDBInput_2";

								/**
								 * [tDBInput_2 process_data_end ] stop
								 */

								/**
								 * [tDBInput_2 end ] start
								 */

								currentComponent = "tDBInput_2";

							}
						} finally {
							if (rs_tDBInput_2 != null) {
								rs_tDBInput_2.close();
							}
							if (stmt_tDBInput_2 != null) {
								stmt_tDBInput_2.close();
							}
							if (conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {

								log.debug("tDBInput_2 - Connection starting to commit.");

								conn_tDBInput_2.commit();

								log.debug("tDBInput_2 - Connection commit has succeeded.");

								log.debug("tDBInput_2 - Closing the connection to the database.");

								conn_tDBInput_2.close();

								if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
										&& routines.system.BundleUtils.inOSGi()) {
									Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
											.getMethod("checkedShutdown").invoke(null, (Object[]) null);
								}

								log.debug("tDBInput_2 - Connection to the database closed.");

							}

						}
						globalMap.put("tDBInput_2_NB_LINE", nb_line_tDBInput_2);
						log.debug("tDBInput_2 - Retrieved records count: " + nb_line_tDBInput_2 + " .");

						if (log.isDebugEnabled())
							log.debug("tDBInput_2 - " + ("Done."));

						ok_Hash.put("tDBInput_2", true);
						end_Hash.put("tDBInput_2", System.currentTimeMillis());

						/**
						 * [tDBInput_2 end ] stop
						 */
						if (execStat) {
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tDBInput_2);
						}

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Connection starting to commit.");

						conn_tDBInput_1.commit();

						log.debug("tDBInput_1 - Connection commit has succeeded.");

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tDBRow_1 end ] start
				 */

				currentComponent = "tDBRow_1";

				stmt_tDBRow_1.close();
				resourceMap.remove("stmt_tDBRow_1");
				resourceMap.put("statementClosed_tDBRow_1", true);
				if (commitEvery_tDBRow_1 > commitCounter_tDBRow_1) {

					log.debug("tDBRow_1 - Connection starting to commit.");

					conn_tDBRow_1.commit();

					log.debug("tDBRow_1 - Connection commit has succeeded.");

					commitCounter_tDBRow_1 = 0;

				}
				log.debug("tDBRow_1 - Closing the connection to the database.");

				conn_tDBRow_1.close();

				if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
						&& routines.system.BundleUtils.inOSGi()) {
					Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").getMethod("checkedShutdown")
							.invoke(null, (Object[]) null);
				}

				log.debug("tDBRow_1 - Connection to the database closed.");

				resourceMap.put("finish_tDBRow_1", true);
				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				if (log.isDebugEnabled())
					log.debug("tDBRow_1 - " + ("Done."));

				ok_Hash.put("tDBRow_1", true);
				end_Hash.put("tDBRow_1", System.currentTimeMillis());

				/**
				 * [tDBRow_1 end ] stop
				 */

				/**
				 * [tDBRow_2 end ] start
				 */

				currentComponent = "tDBRow_2";

				stmt_tDBRow_2.close();
				resourceMap.remove("stmt_tDBRow_2");
				resourceMap.put("statementClosed_tDBRow_2", true);
				if (commitEvery_tDBRow_2 > commitCounter_tDBRow_2) {

					log.debug("tDBRow_2 - Connection starting to commit.");

					conn_tDBRow_2.commit();

					log.debug("tDBRow_2 - Connection commit has succeeded.");

					commitCounter_tDBRow_2 = 0;

				}
				log.debug("tDBRow_2 - Closing the connection to the database.");

				conn_tDBRow_2.close();

				if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
						&& routines.system.BundleUtils.inOSGi()) {
					Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").getMethod("checkedShutdown")
							.invoke(null, (Object[]) null);
				}

				log.debug("tDBRow_2 - Connection to the database closed.");

				resourceMap.put("finish_tDBRow_2", true);
				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				if (log.isDebugEnabled())
					log.debug("tDBRow_2 - " + ("Done."));

				ok_Hash.put("tDBRow_2", true);
				end_Hash.put("tDBRow_2", System.currentTimeMillis());

				/**
				 * [tDBRow_2 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
					java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(), sqle_tDBOutput_1 = null;
					String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(
								e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(),
								ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					} else {
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (errormessage_tDBOutput_1));
					System.err.println(errormessage_tDBOutput_1);

				}

				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");
				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tDBRow_1 finally ] start
				 */

				currentComponent = "tDBRow_1";

				try {
					if (resourceMap.get("statementClosed_tDBRow_1") == null) {
						java.sql.Statement stmtToClose_tDBRow_1 = null;
						if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
							stmtToClose_tDBRow_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBRow_1") == null) {
						java.sql.Connection ctn_tDBRow_1 = null;
						if ((ctn_tDBRow_1 = (java.sql.Connection) resourceMap.get("conn_tDBRow_1")) != null) {
							try {
								log.debug("tDBRow_1 - Closing the connection to the database.");

								ctn_tDBRow_1.close();
								log.debug("tDBRow_1 - Connection to the database closed.");

							} catch (java.sql.SQLException sqlEx_tDBRow_1) {
								String errorMessage_tDBRow_1 = "failed to close the connection in tDBRow_1 :"
										+ sqlEx_tDBRow_1.getMessage();
								log.error("tDBRow_1 - " + sqlEx_tDBRow_1.getMessage());

								System.err.println(errorMessage_tDBRow_1);
							}
						}
					}
				}

				/**
				 * [tDBRow_1 finally ] stop
				 */

				/**
				 * [tDBRow_2 finally ] start
				 */

				currentComponent = "tDBRow_2";

				try {
					if (resourceMap.get("statementClosed_tDBRow_2") == null) {
						java.sql.Statement stmtToClose_tDBRow_2 = null;
						if ((stmtToClose_tDBRow_2 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_2")) != null) {
							stmtToClose_tDBRow_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBRow_2") == null) {
						java.sql.Connection ctn_tDBRow_2 = null;
						if ((ctn_tDBRow_2 = (java.sql.Connection) resourceMap.get("conn_tDBRow_2")) != null) {
							try {
								log.debug("tDBRow_2 - Closing the connection to the database.");

								ctn_tDBRow_2.close();
								log.debug("tDBRow_2 - Connection to the database closed.");

							} catch (java.sql.SQLException sqlEx_tDBRow_2) {
								String errorMessage_tDBRow_2 = "failed to close the connection in tDBRow_2 :"
										+ sqlEx_tDBRow_2.getMessage();
								log.error("tDBRow_2 - " + sqlEx_tDBRow_2.getMessage());

								System.err.println(errorMessage_tDBRow_2);
							}
						}
					}
				}

				/**
				 * [tDBRow_2 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tDBInput_2 finally ] start
				 */

				currentComponent = "tDBInput_2";

				/**
				 * [tDBInput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final JOB_04_RGPD_DELETE JOB_04_RGPD_DELETEClass = new JOB_04_RGPD_DELETE();

		int exitCode = JOB_04_RGPD_DELETEClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'JOB_04_RGPD_DELETE' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'JOB_04_RGPD_DELETE' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = JOB_04_RGPD_DELETE.class.getClassLoader().getResourceAsStream(
					"etl_m2_projectfinal_kodjo/job_04_rgpd_delete_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = JOB_04_RGPD_DELETE.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : JOB_04_RGPD_DELETE");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 102627 characters generated by Talend Open Studio for Data Integration on the
 * 24 juin 2026 à 15:59:05 CEST
 ************************************************************************************************/